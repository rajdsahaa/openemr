<html>
<head>
<?php html_header_show();?>
<link rel=stylesheet href="<?php echo $css_header;?>" type="text/css">
<title>Export Patient Demographics</title>
</head>
<body>

<p>This is a placeholder for a program to export the currently selected patient's
demographics to some other system.  A typical application would be a laboratory
requisiton system.</p>

<p>See export_labworks.php for a working implementation.  To install an export
program, replace this file with a symbolic link to that program.</p>

<center>
<form>
<p><input type='button' value='OK' onclick='window.close()' /></p>
</form>
</center>

</body>
</html>
