This is a sample form which can be used as a template to create your own custom forms

A few words of wisdom:
======================
1) The folder name you create is important

When you create a new form, copy this whole folder to a new name. If you'd like to create a form for Eye Exams then make a new folder called 'eye_exam' with the contents of this sampleinside of it.


2) Stick with the same name once you've created the form

Every file and database reference in these PHP and SQL scripts refer to your form name explicitly. Once you've chosen a name STICK WITH IT because if you change it half way through then your form won't work.


3) Normally a form requires it's own database table. Be sure to edit the table.sql file appropriately.


4) Look for the lines about CHANGE THIS and take time to read the comments in these example files. They were put there to help YOU!

